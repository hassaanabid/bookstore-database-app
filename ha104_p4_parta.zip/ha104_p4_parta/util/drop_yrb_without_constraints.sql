drop table new_category;
drop table new_club;
drop table new_member;
drop table new_offer;
drop table new_purchase;
drop table new_shipping;